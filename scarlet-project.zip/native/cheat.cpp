// scarlet — CounterFlame root loader (arm64 Android, NDK). запуск: root, из /data/local/tmp
// RVA из script.json билда. патчи через /proc/PID/mem, меню — overlay.apk (встроен, ставится сам).
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cstdint>
#include <ctime>
#include <string>
#include <vector>
#include <map>
#include <unistd.h>
#include <fcntl.h>
#include <dirent.h>
#include <signal.h>
#include <poll.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include "apk_data.h"   // overlay_apk[], overlay_apk_len (генерит CI)

#define PKG  "com.ScarletWork.CounterFlame"
#define OVL  "com.scarlet.overlay"
#define PORT 27042
#define TMP  "/data/local/tmp"

// ── RVA ──
enum : uint64_t {
  R_SETEN    = 0x1DAA674,  // WireframeWallhack.SetEnabled(bool) static
  R_CULL_WH  = 0x276D864,  // PlayerCulling.IsWallhacked -> bool
  R_CULL_OCC = 0x276CF20,  // PlayerCulling.SetOccluded -> void
  R_GOD_GET  = 0x10ACDF4,  // ArmsController.get_IsGod -> bool
  R_PC_DMG   = 0x27768E8,  // PlayerController.TakeDamage -> void
  R_MAG      = 0x10AC200,  // Ammunition.get_MagazineCapacity -> int16
  R_CAP      = 0x10AC208,  // Ammunition.get_Capacity -> int16
  R_RECOIL   = 0x10B8C6C,  // ArmsController.ApplyCameraRecoil -> void
};
static const uint32_t I_RET = 0xD65F03C0, I_MOV1 = 0x52800020, I_MOV999 = 0x52807CE0;

// b <to> из слота по адресу from (оба RVA)
static uint32_t b_to(uint64_t from, uint64_t to) {
  int64_t d = ((int64_t)to - (int64_t)from) / 4;
  return 0x14000000u | ((uint32_t)d & 0x03FFFFFFu);
}

struct Patch   { uint64_t rva; uint32_t ins[2]; int n; };
struct Feature { const char* name; Patch p[3]; int np; bool on; };

static Feature F[4] = {
  // esp: игра сама включает свой wireframe — IsWallhacked превращаем в mov w0,#1 ; b SetEnabled
  { "esp", { {R_CULL_OCC,{I_RET,0},1}, {R_CULL_WH,{I_MOV1,0},2}, {0,{0,0},0} }, 2, false },
  { "rc",  { {R_RECOIL,{I_RET,0},1}, {0,{0,0},0}, {0,{0,0},0} }, 1, false },
  { "am",  { {R_MAG,{I_MOV999,I_RET},2}, {R_CAP,{I_MOV999,I_RET},2}, {0,{0,0},0} }, 2, false },
  { "god", { {R_GOD_GET,{I_MOV1,I_RET},2}, {R_PC_DMG,{I_RET,0},1}, {0,{0,0},0} }, 2, false },
};

static int g_pid = 0, g_mem = -1, g_cli = -1;
static uint64_t g_base = 0;
static std::map<uint64_t, std::vector<uint8_t>> g_orig;

static bool rd(uint64_t a, void* b, size_t n) { return pread64(g_mem, b, n, (off64_t)a) == (ssize_t)n; }
static bool wr(uint64_t a, const void* b, size_t n) { return pwrite64(g_mem, b, n, (off64_t)a) == (ssize_t)n; }

static void revert(Feature& f) {
  for (int i = 0; i < f.np; i++) {
    auto it = g_orig.find(f.p[i].rva);
    if (it == g_orig.end()) continue;
    wr(g_base + f.p[i].rva, it->second.data(), it->second.size());
    g_orig.erase(it);
  }
  f.on = false;
}

static bool apply(Feature& f) {
  bool ok = true;
  for (int i = 0; i < f.np && ok; i++) {
    Patch& p = f.p[i]; uint64_t a = g_base + p.rva; size_t n = p.n * 4;
    if (!g_orig.count(p.rva)) {
      std::vector<uint8_t> o(n);
      if (!rd(a, o.data(), n)) { ok = false; break; }
      g_orig[p.rva] = o;
    }
    uint8_t v[8];
    if (!wr(a, p.ins, n) || !rd(a, v, n) || memcmp(v, p.ins, n)) ok = false;
  }
  if (!ok) { revert(f); return false; }
  f.on = true; return true;
}

static std::string cmdline(int pid) {
  char path[48], buf[256] = {0};
  snprintf(path, sizeof path, "/proc/%d/cmdline", pid);
  int fd = open(path, O_RDONLY); if (fd < 0) return "";
  ssize_t r = read(fd, buf, sizeof buf - 1); (void)r; close(fd);
  return buf;
}

static int find_pid() {
  DIR* d = opendir("/proc"); if (!d) return 0;
  int res = 0; dirent* e;
  while ((e = readdir(d))) {
    int p = atoi(e->d_name);
    if (p > 1 && cmdline(p) == PKG) { res = p; break; }
  }
  closedir(d); return res;
}

static bool excluded(const char* l) {
  static const char* x[] = {"/system", "/apex", "/vendor", "/dev/", "[", "dalvik", ".art", ".oat", ".odex", ".vdex", ".dex", ".ttf"};
  for (auto s : x) if (strstr(l, s)) return true;
  return false;
}

// база libil2cpp: по имени в maps, иначе ELF-скан (e_shoff больше последнего RVA из дампа)
static uint64_t find_base(int pid) {
  char path[48]; snprintf(path, sizeof path, "/proc/%d/maps", pid);
  FILE* f = fopen(path, "r"); if (!f) return 0;
  char line[1024]; uint64_t first = 0, best = 0, bestOff = 0;
  std::vector<uint64_t> cand;
  while (fgets(line, sizeof line, f)) {
    unsigned long long s, e; char perm[8] = {0};
    if (sscanf(line, "%llx-%llx %7s", &s, &e, perm) < 3) continue;
    if (strstr(line, "libil2cpp.so")) { if (!first) first = s; }
    else if (!strcmp(perm, "r--p") && !excluded(line)) cand.push_back(s);
  }
  fclose(f);
  if (first) return first;
  for (auto a : cand) {
    uint32_t m = 0; uint64_t sh = 0;
    if (!rd(a, &m, 4) || m != 0x464C457F || !rd(a + 0x28, &sh, 8)) continue;
    if (sh > 0x2A50000 && sh > bestOff) { bestOff = sh; best = a; }
  }
  return best;
}

static void send_state() {
  if (g_cli < 0) return;
  char b[200];
  int n = snprintf(b, sizeof b, "STATE pid=%d base=%llx esp=%d rc=%d am=%d god=%d\n", g_pid,
                   (unsigned long long)g_base, F[0].on, F[1].on, F[2].on, F[3].on);
  send(g_cli, b, n, MSG_NOSIGNAL);
}

static void detach() {
  if (g_mem >= 0) close(g_mem);
  g_mem = -1; g_pid = 0; g_base = 0; g_orig.clear();
  for (auto& f : F) f.on = false;
}

static bool attach() {
  int pid = find_pid(); if (!pid) return false;
  char path[48]; snprintf(path, sizeof path, "/proc/%d/mem", pid);
  g_mem = open(path, O_RDWR); if (g_mem < 0) return false;
  uint64_t b = find_base(pid); uint32_t m = 0;
  if (!b || !rd(b, &m, 4) || m != 0x464C457F) { close(g_mem); g_mem = -1; return false; }
  g_pid = pid; g_base = b;
  printf("attach pid=%d base=0x%llx\n", g_pid, (unsigned long long)g_base); fflush(stdout);
  return true;
}

static void handle(const std::string& l) {
  char name[16]; int v;
  if (sscanf(l.c_str(), "SET %15s %d", name, &v) != 2) return;
  if (!g_pid) { send(g_cli, "ERR nogame\n", 11, MSG_NOSIGNAL); return; }
  for (auto& f : F) if (!strcmp(f.name, name)) {
    bool ok = true;
    if (v) ok = apply(f); else revert(f);
    printf("%s=%d -> %s\n", name, v, ok ? "ok" : "FAIL"); fflush(stdout);
    if (!ok) { char b[48]; int n = snprintf(b, sizeof b, "ERR %s\n", name); send(g_cli, b, n, MSG_NOSIGNAL); }
  }
  send_state();
}

static volatile sig_atomic_t g_run = 1;
static void on_sig(int) { g_run = 0; }

static void install_overlay() {
  FILE* f = fopen(TMP "/scarlet_overlay.apk", "wb");
  if (!f) return;
  fwrite(overlay_apk, 1, overlay_apk_len, f); fclose(f);
  chmod(TMP "/scarlet_overlay.apk", 0644);
  system("pm install -r -g " TMP "/scarlet_overlay.apk >" TMP "/scarlet_pm.log 2>&1");
  system("appops set " OVL " SYSTEM_ALERT_WINDOW allow");
  system("am start -n " OVL "/.MainActivity >/dev/null 2>&1");
}

#ifndef SCARLET_TEST
int main(int argc, char** argv) {
  bool fg = argc > 1 && !strcmp(argv[1], "-f");
  if (getuid() != 0) { fprintf(stderr, "нужен root: su -c %s\n", argv[0]); return 1; }

  // убить старый экземпляр
  if (FILE* pf = fopen(TMP "/scarlet.pid", "r")) {
    int old = 0;
    if (fscanf(pf, "%d", &old) == 1 && old > 1 && old != getpid() && cmdline(old).find("scarlet") != std::string::npos) {
      kill(old, SIGTERM); usleep(400000);
    }
    fclose(pf);
  }
  if (!fg) {
    pid_t p = fork(); if (p < 0) return 1;
    if (p > 0) { printf("scarlet запущен (pid %d). в игре: плавающая кнопка S\n", p); return 0; }
    setsid();
    int fd = open(TMP "/scarlet.log", O_WRONLY | O_CREAT | O_TRUNC, 0644);
    dup2(fd, 1); dup2(fd, 2); dup2(open("/dev/null", O_RDONLY), 0);
  }
  if (FILE* pf = fopen(TMP "/scarlet.pid", "w")) { fprintf(pf, "%d\n", getpid()); fclose(pf); }
  setvbuf(stdout, nullptr, _IOLBF, 0);
  signal(SIGPIPE, SIG_IGN); signal(SIGTERM, on_sig); signal(SIGINT, on_sig);

  F[0].p[1].ins[1] = b_to(R_CULL_WH + 4, R_SETEN);

  int lis = socket(AF_INET, SOCK_STREAM, 0), one = 1;
  setsockopt(lis, SOL_SOCKET, SO_REUSEADDR, &one, sizeof one);
  sockaddr_in a{}; a.sin_family = AF_INET; a.sin_port = htons(PORT); a.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
  if (bind(lis, (sockaddr*)&a, sizeof a) || listen(lis, 1)) { perror("bind"); return 1; }

  install_overlay();

  std::string buf; time_t lastTry = 0;
  while (g_run) {
    time_t now = time(0);
    if (g_pid && cmdline(g_pid) != PKG) { detach(); send_state(); }
    if (!g_pid && now != lastTry) { lastTry = now; if (attach()) send_state(); }

    pollfd pf[2]; int n = 0;
    pf[n++] = {lis, POLLIN, 0};
    if (g_cli >= 0) pf[n++] = {g_cli, POLLIN, 0};
    poll(pf, n, 500);
    if (pf[0].revents & POLLIN) {
      int c = accept(lis, nullptr, nullptr);
      if (c >= 0) { if (g_cli >= 0) close(g_cli); g_cli = c; buf.clear(); send_state(); }
    }
    if (g_cli >= 0 && n > 1 && (pf[1].revents & (POLLIN | POLLHUP | POLLERR))) {
      char t[256]; ssize_t r = recv(g_cli, t, sizeof t, 0);
      if (r <= 0) { close(g_cli); g_cli = -1; }
      else {
        buf.append(t, r); size_t p;
        while ((p = buf.find('\n')) != std::string::npos) { handle(buf.substr(0, p)); buf.erase(0, p + 1); }
      }
    }
  }
  if (g_pid) for (auto& f : F) if (f.on) revert(f);
  unlink(TMP "/scarlet.pid");
  return 0;
}
#endif
