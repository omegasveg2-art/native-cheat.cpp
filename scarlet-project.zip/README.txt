1. GitHub -> New repository -> залей эту папку целиком (включая .github/workflows/build.yml)
2. Actions -> build -> Run workflow (или просто push). ~5 минут.
3. Artifacts -> scarlet (zip) -> достань файл scarlet
4. Кинь scarlet в /data/local/tmp, chmod 755, запусти под рутом:  /data/local/tmp/scarlet
   Игра запущена -> в игре плавающая кнопка S -> меню.
Логи: /data/local/tmp/scarlet.log  (проблемы с установкой оверлея: scarlet_pm.log)
