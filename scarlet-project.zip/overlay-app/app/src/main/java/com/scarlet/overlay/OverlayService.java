package com.scarlet.overlay;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class OverlayService extends Service {
    static final int PORT = 27042;
    static final String[] KEYS = {"esp", "rc", "am", "god"};
    static final String[] LABELS = {"ESP (wireframe)", "No recoil", "Inf ammo", "God"};

    WindowManager wm;
    TextView bubble, status;
    LinearLayout panel;
    Switch[] sw = new Switch[4];
    WindowManager.LayoutParams bp, pp;
    boolean panelShown = false, updating = false;
    final Handler ui = new Handler(Looper.getMainLooper());
    final ExecutorService io = Executors.newSingleThreadExecutor();
    volatile boolean run = true;
    volatile OutputStream out;

    int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent i, int f, int id) {
        if (wm == null) {
            goForeground();
            wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
            buildBubble();
            buildPanel();
            new Thread(this::netLoop).start();
        }
        return START_STICKY;
    }

    void goForeground() {
        String ch = "scarlet";
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            nm.createNotificationChannel(new NotificationChannel(ch, "scarlet", NotificationManager.IMPORTANCE_MIN));
        }
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, ch) : new Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.ic_menu_manage).setContentTitle("scarlet");
        startForeground(1, b.build());
    }

    WindowManager.LayoutParams lp(int w, int h) {
        int type = Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(w, h, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP | Gravity.START;
        return p;
    }

    void buildBubble() {
        bubble = new TextView(this);
        bubble.setText("S");
        bubble.setTextColor(Color.WHITE);
        bubble.setTextSize(18);
        bubble.setGravity(Gravity.CENTER);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(Color.parseColor("#CCB71C1C"));
        bubble.setBackground(g);
        bp = lp(dp(44), dp(44));
        bp.x = dp(8);
        bp.y = dp(120);
        bubble.setOnTouchListener(new View.OnTouchListener() {
            float dx, dy; int sx, sy; boolean moved;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        dx = e.getRawX(); dy = e.getRawY(); sx = bp.x; sy = bp.y; moved = false; return true;
                    case MotionEvent.ACTION_MOVE:
                        float mx = e.getRawX() - dx, my = e.getRawY() - dy;
                        if (Math.abs(mx) > dp(6) || Math.abs(my) > dp(6)) moved = true;
                        if (moved) { bp.x = sx + (int) mx; bp.y = sy + (int) my; wm.updateViewLayout(bubble, bp); }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) togglePanel();
                        return true;
                }
                return false;
            }
        });
        wm.addView(bubble, bp);
    }

    void buildPanel() {
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(12), dp(10), dp(12), dp(10));
        GradientDrawable g = new GradientDrawable();
        g.setColor(Color.parseColor("#EE1B1B1B"));
        g.setCornerRadius(dp(10));
        panel.setBackground(g);

        status = new TextView(this);
        status.setTextColor(Color.parseColor("#BBBBBB"));
        status.setTextSize(12);
        status.setText("нет связи с scarlet");
        panel.addView(status);

        for (int i = 0; i < 4; i++) {
            final int idx = i;
            Switch s = new Switch(this);
            s.setText(LABELS[i]);
            s.setTextColor(Color.WHITE);
            s.setPadding(0, dp(6), 0, dp(6));
            s.setOnCheckedChangeListener((b, on) -> {
                if (!updating) send("SET " + KEYS[idx] + " " + (on ? 1 : 0));
            });
            sw[i] = s;
            panel.addView(s, new LinearLayout.LayoutParams(dp(200), LinearLayout.LayoutParams.WRAP_CONTENT));
        }

        Button close = new Button(this);
        close.setText("скрыть");
        close.setOnClickListener(v -> togglePanel());
        panel.addView(close);

        pp = lp(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT);
    }

    void togglePanel() {
        if (panelShown) {
            wm.removeView(panel);
        } else {
            pp.x = bp.x + dp(52);
            pp.y = bp.y;
            wm.addView(panel, pp);
        }
        panelShown = !panelShown;
    }

    void send(final String line) {
        io.execute(() -> {
            try {
                OutputStream o = out;
                if (o != null) { o.write((line + "\n").getBytes()); o.flush(); }
            } catch (Exception ignored) { }
        });
    }

    void netLoop() {
        while (run) {
            try (Socket s = new Socket("127.0.0.1", PORT)) {
                out = s.getOutputStream();
                BufferedReader r = new BufferedReader(new InputStreamReader(s.getInputStream()));
                String l;
                while (run && (l = r.readLine()) != null) onLine(l);
            } catch (Exception ignored) { }
            out = null;
            ui.post(() -> status.setText("нет связи с scarlet"));
            try { Thread.sleep(1000); } catch (Exception ignored) { }
        }
    }

    void onLine(final String l) {
        if (l.startsWith("ERR")) {
            ui.post(() -> status.setText(l.equals("ERR nogame") ? "игра не найдена" : "не вышло: " + l.substring(4)));
            return;
        }
        if (!l.startsWith("STATE ")) return;
        final java.util.HashMap<String, String> m = new java.util.HashMap<>();
        for (String t : l.substring(6).split(" ")) {
            int e = t.indexOf('=');
            if (e > 0) m.put(t.substring(0, e), t.substring(e + 1));
        }
        ui.post(() -> {
            boolean attached = !"0".equals(m.get("pid"));
            status.setText(attached ? "игра: pid " + m.get("pid") : "игра не найдена");
            updating = true;
            for (int i = 0; i < 4; i++) sw[i].setChecked("1".equals(m.get(KEYS[i])));
            updating = false;
        });
    }

    @Override public void onDestroy() {
        run = false;
        try { wm.removeView(bubble); } catch (Exception ignored) { }
        if (panelShown) try { wm.removeView(panel); } catch (Exception ignored) { }
        io.shutdownNow();
        super.onDestroy();
    }
}
